
import jsPDF from 'jspdf';
import { Claim } from '@/hooks/useClaims';
import { Evidence } from '@/hooks/useEvidence';

export const generateClaimEvidencePDF = (
  claim: Claim,
  evidenceList: Evidence[]
) => {
  const pdf = new jsPDF();
  let yPosition = 20;
  const margin = 20;
  const pageWidth = pdf.internal.pageSize.width;
  const pageHeight = pdf.internal.pageSize.height;

  // Helper function to add new page if needed
  const checkPageBreak = (neededSpace: number) => {
    if (yPosition + neededSpace > pageHeight - margin) {
      pdf.addPage();
      yPosition = margin;
    }
  };

  // Helper function to wrap text
  const addWrappedText = (text: string, x: number, y: number, maxWidth: number, fontSize: number = 12) => {
    pdf.setFontSize(fontSize);
    const lines = pdf.splitTextToSize(text, maxWidth);
    pdf.text(lines, x, y);
    return lines.length * (fontSize * 0.5); // Approximate line height
  };

  // Title
  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Claim Evidence Report', margin, yPosition);
  yPosition += 15;

  // Claim Information
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Claim Information', margin, yPosition);
  yPosition += 10;

  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  
  const claimInfo = [
    `Title: ${claim.title}`,
    `Case Number: ${claim.case_number}`,
    `Court: ${claim.court || 'N/A'}`,
    `Plaintiff: ${claim.plaintiff_name || 'N/A'}`,
    `Defendant: ${claim.defendant_name || 'N/A'}`,
    `Status: ${claim.status}`,
    `Description: ${claim.description || 'N/A'}`
  ];

  claimInfo.forEach(info => {
    checkPageBreak(8);
    const textHeight = addWrappedText(info, margin, yPosition, pageWidth - 2 * margin, 10);
    yPosition += Math.max(textHeight, 8);
  });

  yPosition += 10;

  // Evidence Section
  checkPageBreak(20);
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Evidence Items', margin, yPosition);
  yPosition += 15;

  if (evidenceList.length === 0) {
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.text('No evidence items found.', margin, yPosition);
  } else {
    evidenceList.forEach((evidence, index) => {
      checkPageBreak(40);
      
      // Evidence header
      pdf.setFontSize(12);
      pdf.setFont('helvetica', 'bold');
      pdf.text(`${index + 1}. ${evidence.exhibit_id || 'Untitled Evidence'}`, margin, yPosition);
      yPosition += 8;

      // Evidence details
      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'normal');
      
      const evidenceDetails = [
        `Description: ${evidence.description}`,
        `File: ${evidence.file_name || 'No file attached'}`,
        `Pages: ${evidence.number_of_pages || 'N/A'}`
      ];

      evidenceDetails.forEach(detail => {
        checkPageBreak(8);
        const textHeight = addWrappedText(detail, margin + 10, yPosition, pageWidth - 2 * margin - 10, 10);
        yPosition += Math.max(textHeight, 8);
      });

      yPosition += 10;
    });
  }

  // Footer
  const totalPages = pdf.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    pdf.setPage(i);
    pdf.setFontSize(8);
    pdf.setFont('helvetica', 'normal');
    pdf.text(
      `Generated on ${new Date().toLocaleDateString()} - Page ${i} of ${totalPages}`,
      margin,
      pageHeight - 10
    );
  }

  return pdf;
};

export const generateEvidenceSummaryPDF = (
  allClaims: Claim[],
  allEvidence: Evidence[]
) => {
  const pdf = new jsPDF();
  let yPosition = 20;
  const margin = 20;
  const pageWidth = pdf.internal.pageSize.width;
  const pageHeight = pdf.internal.pageSize.height;

  // Helper function to add new page if needed
  const checkPageBreak = (neededSpace: number) => {
    if (yPosition + neededSpace > pageHeight - margin) {
      pdf.addPage();
      yPosition = margin;
    }
  };

  // Title
  pdf.setFontSize(18);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Evidence Summary Report', margin, yPosition);
  yPosition += 20;

  // Summary statistics
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Summary Statistics', margin, yPosition);
  yPosition += 10;

  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  
  const stats = [
    `Total Claims: ${allClaims.length}`,
    `Total Evidence Items: ${allEvidence.length}`,
    `Evidence with Files: ${allEvidence.filter(e => e.file_name).length}`,
    `Generated: ${new Date().toLocaleString()}`
  ];

  stats.forEach(stat => {
    pdf.text(stat, margin, yPosition);
    yPosition += 8;
  });

  yPosition += 15;

  // Claims breakdown
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'bold');
  pdf.text('Claims Breakdown', margin, yPosition);
  yPosition += 10;

  allClaims.forEach((claim, index) => {
    checkPageBreak(25);
    
    const claimEvidence = allEvidence.filter(e => e.claimIds.includes(claim.id));
    
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'bold');
    pdf.text(`${index + 1}. ${claim.title}`, margin, yPosition);
    yPosition += 8;

    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Case: ${claim.case_number} | Evidence Items: ${claimEvidence.length}`, margin + 10, yPosition);
    yPosition += 12;
  });

  // Footer
  const totalPages = pdf.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    pdf.setPage(i);
    pdf.setFontSize(8);
    pdf.setFont('helvetica', 'normal');
    pdf.text(
      `Generated on ${new Date().toLocaleDateString()} - Page ${i} of ${totalPages}`,
      margin,
      pageHeight - 10
    );
  }

  return pdf;
};
