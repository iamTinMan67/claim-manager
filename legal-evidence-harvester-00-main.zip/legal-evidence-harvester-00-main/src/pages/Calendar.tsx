
import { Navigation } from "@/components/Navigation";
import { GoogleCalendar } from "@/components/GoogleCalendar";

const Calendar = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <div className="container mx-auto p-4">
        <div className="bg-white shadow-md rounded-lg p-6 max-w-5xl mx-auto">
          <h1 className="text-2xl font-bold mb-6 text-center text-gray-900">
            Case Calendar
          </h1>
          <GoogleCalendar />
        </div>
      </div>
    </div>
  );
};

export default Calendar;
