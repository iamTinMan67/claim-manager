import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { Navigation } from "@/components/Navigation";
import { ClaimsList } from "@/components/ClaimsList";
import { AddClaimModal } from "@/components/AddClaimModal";
import { ClaimEvidenceManager } from "@/components/ClaimEvidenceManager";
import { useAuth } from "@/contexts/AuthContext";
import { useClaims } from "@/hooks/useClaims";
import { useEvidence } from "@/hooks/useEvidence";
import { Evidence } from "@/types/evidence";
import { Button } from "@/components/ui/button";

const Index = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [showAddClaim, setShowAddClaim] = useState(false);
  const [selectedClaimId, setSelectedClaimId] = useState<string | null>(null);
  
  const { claims, loading: claimsLoading, addClaim, deleteClaim } = useClaims();
  const { 
    evidence, 
    loading: evidenceLoading, 
    addEvidence, 
    deleteEvidence, 
    linkEvidenceToClaim, 
    unlinkEvidenceFromClaim 
  } = useEvidence();

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  // Show loading while checking auth or if not authenticated
  if (authLoading || !user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  const handleAddClaim = async (claimData: Parameters<typeof addClaim>[0]) => {
    await addClaim(claimData);
    setShowAddClaim(false);
  };

  const handleAddEvidence = async (evidenceData: Omit<Evidence, "id" | "claimIds">, claimIds: string[]) => {
    console.log('Index handleAddEvidence called with:', evidenceData, claimIds);
    await addEvidence(evidenceData, claimIds);
  };

  const handleRemoveEvidence = async (evidenceId: string) => {
    await deleteEvidence(evidenceId);
  };

  const handleLinkEvidence = async (evidenceId: string, claimId: string) => {
    await linkEvidenceToClaim(evidenceId, claimId);
  };

  const handleUnlinkEvidence = async (evidenceId: string, claimId: string) => {
    await unlinkEvidenceFromClaim(evidenceId, claimId);
  };

  const handleDeleteClaim = async (claimId: string) => {
    await deleteClaim(claimId);
    // Clear selected claim if it was deleted
    if (selectedClaimId === claimId) {
      setSelectedClaimId(null);
    }
  };

  const handleUpdateEvidence = async (evidenceId: string, updates: Partial<Evidence>) => {
    // For now, we'll just show a success message since the backend update isn't implemented
    console.log('Updating evidence:', evidenceId, updates);
    // This would normally call an update service method
  };

  const handleReorderEvidence = async (evidenceList: Evidence[]) => {
    // For now, we'll just show a success message since the backend reorder isn't implemented
    console.log('Reordering evidence:', evidenceList.map(e => e.id));
    // This would normally call a reorder service method
  };

  // Show welcome message if no claims exist yet
  if (!claimsLoading && claims.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="container mx-auto p-4">
          <div className="bg-white shadow-md rounded-lg p-6 max-w-4xl mx-auto text-center">
            <h1 className="text-3xl font-bold mb-4 text-gray-900">
              Welcome to Claim Manager
            </h1>
            <p className="text-gray-600 mb-6">
              Get started by creating your first claim to begin managing evidence and documentation.
            </p>
            <Button
              onClick={() => setShowAddClaim(true)}
              className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors"
            >
              Create Your First Claim
            </Button>
          </div>

          {showAddClaim && (
            <AddClaimModal
              onClose={() => setShowAddClaim(false)}
              onAdd={handleAddClaim}
            />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <div className="container mx-auto p-4">
        <div className="bg-white shadow-md rounded-lg p-6 max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold mb-6 text-center text-gray-900">
            Multi-Claim Evidence Management System
          </h1>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Claims List */}
            <div className="lg:col-span-1">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-900">Claims</h2>
                <button
                  onClick={() => setShowAddClaim(true)}
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors text-sm"
                >
                  Add Claim
                </button>
              </div>
              
              {claimsLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="mt-2 text-gray-600">Loading claims...</p>
                </div>
              ) : (
                <ClaimsList 
                  claims={claims}
                  selectedClaimId={selectedClaimId}
                  onSelectClaim={setSelectedClaimId}
                  evidenceList={evidence}
                />
              )}
            </div>

            {/* Evidence Management */}
            <div className="lg:col-span-2">
              {selectedClaimId ? (
                <ClaimEvidenceManager
                  claim={claims.find(c => c.id === selectedClaimId)!}
                  evidenceList={evidence}
                  allClaims={claims}
                  onAddEvidence={handleAddEvidence}
                  onRemoveEvidence={handleRemoveEvidence}
                  onLinkEvidence={handleLinkEvidence}
                  onUnlinkEvidence={handleUnlinkEvidence}
                  onDeleteClaim={handleDeleteClaim}
                  onUpdateEvidence={handleUpdateEvidence}
                  onReorderEvidence={handleReorderEvidence}
                />
              ) : (
                <div className="text-center text-gray-500 mt-20">
                  <h3 className="text-lg font-medium mb-2">Select a claim to manage evidence</h3>
                  <p>Choose a claim from the left panel to view and manage its evidence.</p>
                </div>
              )}
            </div>
          </div>

          {showAddClaim && (
            <AddClaimModal
              onClose={() => setShowAddClaim(false)}
              onAdd={handleAddClaim}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default Index;
