
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { retryWithReauth, isAuthError } from '@/utils/authUtils';

export interface Claim {
  id: string;
  title: string;
  case_number: string;
  court: string | null;
  plaintiff_name: string | null;
  defendant_name: string | null;
  description: string | null;
  status: 'Active' | 'Pending' | 'Closed';
  created_at: string;
  updated_at: string;
}

export const useClaims = () => {
  const [claims, setClaims] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const fetchClaims = async () => {
    if (!user) return;
    
    setLoading(true);
    
    try {
      const operation = async () => {
        const { data, error } = await supabase
          .from('claims')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;

        // Cast the status to the proper union type
        const mappedClaims = (data || []).map(claim => ({
          ...claim,
          status: claim.status as 'Active' | 'Pending' | 'Closed'
        }));

        return mappedClaims;
      };

      const result = await retryWithReauth(operation);
      setClaims(result);
    } catch (error) {
      console.error('Error fetching claims:', error);
      
      if (isAuthError(error)) {
        toast({
          title: "Authentication Error",
          description: "Please refresh your session or log in again",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to fetch claims",
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const addClaim = async (claimData: Omit<Claim, 'id' | 'created_at' | 'updated_at'>) => {
    if (!user) return;

    try {
      const operation = async () => {
        const { data, error } = await supabase
          .from('claims')
          .insert([{ ...claimData, user_id: user.id }])
          .select()
          .single();

        if (error) throw error;
        return data;
      };

      const data = await retryWithReauth(operation);
      const mappedClaim = {
        ...data,
        status: data.status as 'Active' | 'Pending' | 'Closed'
      };
      setClaims(prev => [mappedClaim, ...prev]);
      toast({
        title: "Success",
        description: "Claim created successfully",
      });
      return mappedClaim;
    } catch (error) {
      console.error('Error adding claim:', error);
      
      if (isAuthError(error)) {
        toast({
          title: "Authentication Error",
          description: "Please refresh your session or log in again",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to create claim",
          variant: "destructive",
        });
      }
      return null;
    }
  };

  const updateClaim = async (id: string, updates: Partial<Claim>) => {
    if (!user) return;

    try {
      const operation = async () => {
        const { data, error } = await supabase
          .from('claims')
          .update(updates)
          .eq('id', id)
          .select()
          .single();

        if (error) throw error;
        return data;
      };

      const data = await retryWithReauth(operation);
      const mappedClaim = {
        ...data,
        status: data.status as 'Active' | 'Pending' | 'Closed'
      };
      setClaims(prev => prev.map(claim => claim.id === id ? mappedClaim : claim));
      toast({
        title: "Success",
        description: "Claim updated successfully",
      });
    } catch (error) {
      console.error('Error updating claim:', error);
      
      if (isAuthError(error)) {
        toast({
          title: "Authentication Error",
          description: "Please refresh your session or log in again",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to update claim",
          variant: "destructive",
        });
      }
    }
  };

  const deleteClaim = async (id: string) => {
    if (!user) return;

    try {
      const operation = async () => {
        // First delete all evidence-claim relationships
        const { error: linkError } = await supabase
          .from('evidence_claims')
          .delete()
          .eq('claim_id', id);

        if (linkError) throw linkError;

        // Then delete the claim
        const { error } = await supabase
          .from('claims')
          .delete()
          .eq('id', id);

        if (error) throw error;
      };

      await retryWithReauth(operation);
      setClaims(prev => prev.filter(claim => claim.id !== id));
      toast({
        title: "Success",
        description: "Claim deleted successfully",
      });
    } catch (error) {
      console.error('Error deleting claim:', error);
      
      if (isAuthError(error)) {
        toast({
          title: "Authentication Error",
          description: "Please refresh your session or log in again",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to delete claim",
          variant: "destructive",
        });
      }
    }
  };

  useEffect(() => {
    if (user) {
      fetchClaims();
    }
  }, [user]);

  return {
    claims,
    loading,
    addClaim,
    updateClaim,
    deleteClaim,
    refetch: fetchClaims,
  };
};
