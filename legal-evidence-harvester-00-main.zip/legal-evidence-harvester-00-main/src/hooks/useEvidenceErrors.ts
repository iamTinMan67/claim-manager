
import { toast } from '@/hooks/use-toast';
import { isAuthError } from '@/utils/authUtils';

export const useEvidenceErrors = () => {
  const handleError = (error: any, operation: string) => {
    console.error(`Error ${operation}:`, error);
    
    if (isAuthError(error)) {
      toast({
        title: "Authentication Error",
        description: "Please refresh your session or log in again",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Error",
        description: `Failed to ${operation}`,
        variant: "destructive",
      });
    }
  };

  const handleSuccess = (message: string) => {
    toast({
      title: "Success",
      description: message,
    });
  };

  const handleWarning = (message: string) => {
    toast({
      title: "Warning",
      description: message,
      variant: "destructive",
    });
  };

  return { handleError, handleSuccess, handleWarning };
};
