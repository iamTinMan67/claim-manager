
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Evidence } from '@/types/evidence';
import { EvidenceService } from '@/services/evidenceService';
import { useEvidenceErrors } from '@/hooks/useEvidenceErrors';

export const useEvidence = () => {
  const [evidence, setEvidence] = useState<Evidence[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { handleError, handleSuccess, handleWarning } = useEvidenceErrors();

  const fetchEvidence = async () => {
    if (!user) return;
    
    setLoading(true);
    
    try {
      const result = await EvidenceService.fetchEvidence();
      setEvidence(result);
    } catch (error) {
      handleError(error, 'fetch evidence');
    } finally {
      setLoading(false);
    }
  };

  const addEvidence = async (evidenceData: Omit<Evidence, 'id' | 'created_at' | 'updated_at' | 'claimIds'>, claimIds: string[] = []) => {
    if (!user) return;

    console.log('Adding evidence with data:', evidenceData);
    console.log('Claim IDs to link:', claimIds);

    try {
      const data = await EvidenceService.createEvidence(evidenceData, user.id);

      // Link evidence to claims if provided
      if (claimIds.length > 0) {
        try {
          await EvidenceService.linkEvidenceToClaims(data.id, claimIds);
        } catch (linkError) {
          console.error('Error linking evidence to claims:', linkError);
          handleWarning('Evidence created but failed to link to claims');
        }
      }

      // Refresh evidence list to show the new item
      await fetchEvidence();
      
      handleSuccess('Evidence created successfully');
      return data;
    } catch (error) {
      handleError(error, 'create evidence');
      return null;
    }
  };

  const deleteEvidence = async (id: string) => {
    if (!user) return;

    try {
      await EvidenceService.deleteEvidence(id);
      setEvidence(prev => prev.filter(item => item.id !== id));
      handleSuccess('Evidence deleted successfully');
    } catch (error) {
      handleError(error, 'delete evidence');
    }
  };

  const linkEvidenceToClaim = async (evidenceId: string, claimId: string) => {
    if (!user) return;

    try {
      await EvidenceService.linkEvidenceToClaim(evidenceId, claimId);
      await fetchEvidence(); // Refresh to get updated relationships
      handleSuccess('Evidence linked to claim successfully');
    } catch (error) {
      handleError(error, 'link evidence to claim');
    }
  };

  const unlinkEvidenceFromClaim = async (evidenceId: string, claimId: string) => {
    if (!user) return;

    try {
      await EvidenceService.unlinkEvidenceFromClaim(evidenceId, claimId);
      await fetchEvidence(); // Refresh to get updated relationships
      handleSuccess('Evidence unlinked from claim successfully');
    } catch (error) {
      handleError(error, 'unlink evidence from claim');
    }
  };

  useEffect(() => {
    if (user) {
      fetchEvidence();
    }
  }, [user]);

  return {
    evidence,
    loading,
    addEvidence,
    deleteEvidence,
    linkEvidenceToClaim,
    unlinkEvidenceFromClaim,
    refetch: fetchEvidence,
  };
};

// Re-export the Evidence type for backward compatibility
export type { Evidence } from '@/types/evidence';
