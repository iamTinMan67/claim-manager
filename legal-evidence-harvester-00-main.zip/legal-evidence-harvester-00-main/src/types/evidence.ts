
export interface Evidence {
  id: string;
  description: string;
  file_name: string | null;
  file_url: string | null;
  exhibit_id: string | null;
  number_of_pages: number | null;
  created_at: string;
  updated_at: string;
  claimIds: string[];
}

export type EvidenceInput = Omit<Evidence, 'id' | 'created_at' | 'updated_at' | 'claimIds'>;
