
import { useState } from "react";
import { Evidence } from "@/types/evidence";
import { Button } from "./ui/button";
import { Eye, Trash2, Unlink, FileText } from "lucide-react";
import { PDFViewer } from "./PDFViewer";

interface Props {
  evidenceList: Evidence[];
  onRemove: (id: string) => void;
  showClaimInfo?: boolean;
  onUnlinkFromClaim?: (evidenceId: string) => void;
}

export const EvidenceTable = ({ 
  evidenceList, 
  onRemove, 
  showClaimInfo = true,
  onUnlinkFromClaim 
}: Props) => {
  const [selectedPDF, setSelectedPDF] = useState<{fileUrl: string, fileName: string} | null>(null);

  const handleViewFile = (evidence: Evidence) => {
    if (evidence.file_url && evidence.file_name) {
      // For PDF files, use the PDF viewer
      if (evidence.file_name.toLowerCase().endsWith('.pdf')) {
        setSelectedPDF({
          fileUrl: evidence.file_url,
          fileName: evidence.file_name
        });
      } else {
        // For other file types, open in new tab
        window.open(evidence.file_url, '_blank');
      }
    }
  };

  if (evidenceList.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
        <p>No evidence items found.</p>
      </div>
    );
  }

  return (
    <>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Exhibit ID
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Description
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                File
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Pages
              </th>
              {showClaimInfo && (
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Claims
                </th>
              )}
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {evidenceList.map((evidence) => (
              <tr key={evidence.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {evidence.exhibit_id || 'N/A'}
                </td>
                <td className="px-6 py-4 text-sm text-gray-900 max-w-xs">
                  <div className="truncate" title={evidence.description}>
                    {evidence.description}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {evidence.file_name ? (
                    <div className="flex items-center space-x-2">
                      <FileText className="w-4 h-4 text-blue-500" />
                      <span className="truncate max-w-[150px]" title={evidence.file_name}>
                        {evidence.file_name}
                      </span>
                      {evidence.file_url && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleViewFile(evidence)}
                          className="p-1"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ) : (
                    <span className="text-gray-400">No file</span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {evidence.number_of_pages || 'N/A'}
                </td>
                {showClaimInfo && (
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                      {evidence.claimIds.length} claim{evidence.claimIds.length !== 1 ? 's' : ''}
                    </span>
                  </td>
                )}
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <div className="flex space-x-2">
                    {onUnlinkFromClaim && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onUnlinkFromClaim(evidence.id)}
                        className="text-orange-600 hover:text-orange-700"
                      >
                        <Unlink className="w-4 h-4" />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRemove(evidence.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedPDF && (
        <PDFViewer
          isOpen={true}
          onClose={() => setSelectedPDF(null)}
          fileUrl={selectedPDF.fileUrl}
          fileName={selectedPDF.fileName}
        />
      )}
    </>
  );
};
