
import { useState } from "react";
import { Evidence } from "@/types/evidence";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { Progress } from "./ui/progress";

interface Props {
  onClose: () => void;
  onAdd: (evidence: Omit<Evidence, "id" | "claimIds">) => void;
}

export const AddEvidenceModal = ({ onClose, onAdd }: Props) => {
  const { user } = useAuth();
  const [evidence, setEvidence] = useState<Omit<Evidence, "id" | "claimIds">>({
    description: "",
    file_name: null,
    file_url: null,
    exhibit_id: null,
    number_of_pages: null,
    created_at: "",
    updated_at: "",
  });

  const [documentTitle, setDocumentTitle] = useState("");
  const [documentNumber, setDocumentNumber] = useState("");
  const [exhibitRef, setExhibitRef] = useState("Exhibit");
  const [numberOfPages, setNumberOfPages] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!documentTitle || !user) {
      return;
    }
    
    setUploading(true);
    
    try {
      let fileUrl = null;
      let fileName = null;

      // Upload file if selected
      if (selectedFile) {
        const fileExt = selectedFile.name.split('.').pop();
        const filePath = `${user.id}/${Date.now()}.${fileExt}`;
        
        setUploadProgress(25);
        
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('evidence-files')
          .upload(filePath, selectedFile);

        if (uploadError) {
          console.error('Upload error:', uploadError);
          toast({
            title: "Upload Error",
            description: "Failed to upload file. Please try again.",
            variant: "destructive",
          });
          return;
        }

        setUploadProgress(75);

        // Get public URL
        const { data: { publicUrl } } = supabase.storage
          .from('evidence-files')
          .getPublicUrl(filePath);

        fileUrl = publicUrl;
        fileName = selectedFile.name;
        setUploadProgress(100);
      }

      // Combine exhibit ref and number for exhibit_id
      const exhibitId = documentNumber ? `${exhibitRef} ${documentNumber}` : exhibitRef;
      
      onAdd({
        ...evidence,
        exhibit_id: exhibitId,
        description: evidence.description || documentTitle,
        file_name: fileName,
        file_url: fileUrl,
        number_of_pages: numberOfPages ? parseInt(numberOfPages) : null,
      });
    } catch (error) {
      console.error('Error in form submission:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (limit to 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "File size must be less than 10MB",
          variant: "destructive",
        });
        e.target.value = '';
        return;
      }
      
      setSelectedFile(file);
      setEvidence({
        ...evidence,
        file_name: file.name,
      });
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add New Evidence</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Single row with Document Title, Exhibit Ref, and Number */}
          <div className="grid grid-cols-6 gap-2">
            <div className="col-span-3 space-y-2">
              <Label htmlFor="document-title">Document Title</Label>
              <Input
                id="document-title"
                value={documentTitle}
                onChange={(e) => setDocumentTitle(e.target.value)}
                required
                disabled={uploading}
              />
            </div>
            <div className="col-span-2 space-y-2">
              <Label htmlFor="exhibit-ref">Exhibit Ref</Label>
              <Input
                id="exhibit-ref"
                value={exhibitRef}
                onChange={(e) => setExhibitRef(e.target.value)}
                disabled={uploading}
              />
            </div>
            <div className="col-span-1 space-y-2">
              <Label htmlFor="document-number">Number</Label>
              <Input
                id="document-number"
                type="number"
                value={documentNumber}
                onChange={(e) => setDocumentNumber(e.target.value)}
                className="text-center"
                disabled={uploading}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="number-of-pages">Number of Pages (Optional)</Label>
            <Input
              id="number-of-pages"
              type="number"
              value={numberOfPages}
              onChange={(e) => setNumberOfPages(e.target.value)}
              disabled={uploading}
              min="1"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              value={evidence.description}
              onChange={(e) =>
                setEvidence({ ...evidence, description: e.target.value })
              }
              className="min-h-[100px]"
              disabled={uploading}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="file">File Upload</Label>
            <Input
              id="file"
              type="file"
              accept=".pdf,.doc,.docx,.xls,.xlsx,.txt,.jpg,.jpeg,.png,.gif,.bmp,.tiff"
              onChange={handleFileChange}
              disabled={uploading}
            />
            <p className="text-xs text-gray-500">Allowed: PDF, Word docs, Excel files, text files, and images (max 10MB)</p>
            {selectedFile && (
              <p className="text-sm text-green-600">Selected: {selectedFile.name}</p>
            )}
          </div>

          {uploading && (
            <div className="space-y-2">
              <Label>Upload Progress</Label>
              <Progress value={uploadProgress} className="w-full" />
            </div>
          )}

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={onClose} disabled={uploading}>
              Cancel
            </Button>
            <Button type="submit" disabled={uploading}>
              {uploading ? "Uploading..." : "Save Evidence"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
