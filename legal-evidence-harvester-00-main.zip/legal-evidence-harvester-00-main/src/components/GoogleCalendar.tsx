export const GoogleCalendar = () => {
  return (
    <div className="mb-6">
      <h2 className="text-xl font-semibold mb-4 text-gray-900">Case Calendar</h2>
      <div className="aspect-video rounded-lg overflow-hidden border">
        <iframe
          src="https://calendar.google.com/calendar/embed?height=600&wkst=1&bgcolor=%23ffffff&showTitle=0&showNav=1&showDate=1&showPrint=0&showTabs=1&showCalendars=0"
          style={{ border: 0 }}
          width="100%"
          height="100%"
          frameBorder="0"
          scrolling="no"
        ></iframe>
      </div>
      <div className="mt-2 text-sm text-gray-600">
        <a
          href="https://calendar.google.com/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:underline"
        >
          Open in Google Calendar
        </a>
      </div>
    </div>
  );
};