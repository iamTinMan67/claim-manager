
import { Claim } from "@/hooks/useClaims";
import { Evidence } from "@/hooks/useEvidence";

interface Props {
  evidenceCount: number;
  claim?: Claim;
  evidenceList?: Evidence[];
}

export const EvidenceSummary = ({ evidenceCount, claim, evidenceList }: Props) => {
  if (!evidenceList || evidenceList.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>No evidence items found.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Claim Information - only on first page */}
      {claim && (
        <div className="bg-blue-50 p-6 rounded-lg mb-8">
          <h2 className="text-xl font-semibold text-blue-900 mb-4">{claim.title}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
            <div className="flex flex-wrap">
              <span className="font-medium text-blue-800 mr-2">Case:</span>
              <span className="text-blue-700">{claim.case_number}</span>
            </div>
            <div className="flex flex-wrap">
              <span className="font-medium text-blue-800 mr-2">Court:</span>
              <span className="text-blue-700">{claim.court || 'N/A'}</span>
            </div>
            <div className="flex flex-wrap">
              <span className="font-medium text-blue-800 mr-2">Status:</span>
              <span className="text-blue-700">{claim.status}</span>
            </div>
            <div className="flex flex-wrap">
              <span className="font-medium text-blue-800 mr-2">Plaintiff:</span>
              <span className="text-blue-700">{claim.plaintiff_name || 'N/A'}</span>
            </div>
            <div className="flex flex-wrap">
              <span className="font-medium text-blue-800 mr-2">Defendant:</span>
              <span className="text-blue-700">{claim.defendant_name || 'N/A'}</span>
            </div>
          </div>
          {claim.description && (
            <div className="mt-4">
              <span className="font-medium text-blue-800">Description:</span>
              <p className="text-blue-700 mt-1">{claim.description}</p>
            </div>
          )}
        </div>
      )}

      {/* Evidence List */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-900">Evidence Items ({evidenceCount})</h3>
        
        <div className="space-y-3">
          {evidenceList.map((evidence, index) => (
            <div key={evidence.id} className="bg-white border rounded-lg p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="flex flex-wrap">
                  <span className="font-medium text-gray-700 mr-2">Exhibit:</span>
                  <span className="text-gray-900">{evidence.exhibit_id || 'N/A'}</span>
                </div>
                <div className="flex flex-wrap">
                  <span className="font-medium text-gray-700 mr-2">Pages:</span>
                  <span className="text-gray-900">{evidence.number_of_pages || 'N/A'}</span>
                </div>
                <div className="flex flex-wrap">
                  <span className="font-medium text-gray-700 mr-2">File:</span>
                  <span className="text-gray-900">{evidence.file_name || 'No file'}</span>
                </div>
                <div className="flex flex-wrap">
                  <span className="font-medium text-gray-700 mr-2">Claims:</span>
                  <span className="text-gray-900">{evidence.claimIds.length}</span>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t">
                <span className="font-medium text-gray-700">Description:</span>
                <p className="text-gray-900 mt-1">{evidence.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
