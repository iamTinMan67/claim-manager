
import { useState } from "react";
import { Claim } from "@/hooks/useClaims";
import { Evidence } from "@/types/evidence";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { EvidenceTable } from "./EvidenceTable";
import { AddEvidenceModal } from "./AddEvidenceModal";
import { EvidenceSummary } from "./EvidenceSummary";
import { ClaimEvidenceExport } from "./ClaimEvidenceExport";
import { LinkEvidenceModal } from "./LinkEvidenceModal";
import { AmendEvidence } from "./AmendEvidence";
import { Button } from "./ui/button";
import { Trash2 } from "lucide-react";

interface Props {
  claim: Claim;
  evidenceList: Evidence[];
  allClaims: Claim[];
  onAddEvidence: (evidence: Omit<Evidence, "id" | "claimIds">, claimIds: string[]) => void;
  onRemoveEvidence: (evidenceId: string) => void;
  onLinkEvidence: (evidenceId: string, claimId: string) => void;
  onUnlinkEvidence: (evidenceId: string, claimId: string) => void;
  onDeleteClaim: (claimId: string) => void;
  onUpdateEvidence: (evidenceId: string, updates: Partial<Evidence>) => void;
  onReorderEvidence: (evidenceList: Evidence[]) => void;
}

export const ClaimEvidenceManager = ({ 
  claim, 
  evidenceList, 
  allClaims,
  onAddEvidence, 
  onRemoveEvidence,
  onLinkEvidence,
  onUnlinkEvidence,
  onDeleteClaim,
  onUpdateEvidence,
  onReorderEvidence
}: Props) => {
  const [showAddEvidence, setShowAddEvidence] = useState(false);
  const [showLinkEvidence, setShowLinkEvidence] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const claimEvidence = evidenceList.filter(evidence => evidence.claimIds.includes(claim.id));

  const handleAddEvidence = (evidence: Omit<Evidence, "id" | "claimIds">) => {
    onAddEvidence(evidence, [claim.id]);
    setShowAddEvidence(false);
  };

  const handleDeleteClaim = () => {
    onDeleteClaim(claim.id);
  };

  return (
    <div className="space-y-6">
      {/* Claim Header */}
      <div className="bg-blue-50 p-4 rounded-lg">
        <div className="flex justify-between items-start mb-2">
          <h2 className="text-xl font-semibold text-blue-900">{claim.title}</h2>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowDeleteConfirm(true)}
            className="text-red-600 hover:text-red-700 border-red-300 hover:border-red-400"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Delete Claim
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-4 text-sm text-blue-800">
          <div>
            <strong>Case:</strong> {claim.case_number}
          </div>
          <div>
            <strong>Court:</strong> {claim.court}
          </div>
          <div>
            <strong>Plaintiff:</strong> {claim.plaintiff_name}
          </div>
          <div>
            <strong>Defendant:</strong> {claim.defendant_name}
          </div>
        </div>
        <p className="text-sm text-blue-700 mt-2">{claim.description}</p>
      </div>

      {/* Delete Confirmation Dialog */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4">Delete Claim</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this claim? This action cannot be undone. 
              All evidence will be unlinked from this claim.
            </p>
            <div className="flex justify-end space-x-3">
              <Button 
                variant="outline" 
                onClick={() => setShowDeleteConfirm(false)}
              >
                Cancel
              </Button>
              <Button 
                variant="destructive" 
                onClick={() => {
                  handleDeleteClaim();
                  setShowDeleteConfirm(false);
                }}
              >
                Delete Claim
              </Button>
            </div>
          </div>
        </div>
      )}

      <Tabs defaultValue="evidence" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="evidence">Evidence</TabsTrigger>
          <TabsTrigger value="amend">Amend Evidence</TabsTrigger>
          <TabsTrigger value="summary">Summary</TabsTrigger>
          <TabsTrigger value="export">Export</TabsTrigger>
        </TabsList>

        <TabsContent value="evidence" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Evidence Items</h3>
            <div className="space-x-2">
              <button
                onClick={() => setShowLinkEvidence(true)}
                className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors text-sm"
              >
                Link Existing Evidence
              </button>
              <button
                onClick={() => setShowAddEvidence(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors text-sm"
              >
                Add New Evidence
              </button>
            </div>
          </div>

          <EvidenceTable 
            evidenceList={claimEvidence}
            onRemove={onRemoveEvidence}
            showClaimInfo={false}
            onUnlinkFromClaim={(evidenceId) => onUnlinkEvidence(evidenceId, claim.id)}
          />
        </TabsContent>

        <TabsContent value="amend">
          <AmendEvidence 
            evidenceList={claimEvidence}
            onUpdateEvidence={onUpdateEvidence}
            onReorderEvidence={onReorderEvidence}
          />
        </TabsContent>

        <TabsContent value="summary">
          <EvidenceSummary 
            evidenceCount={claimEvidence.length}
            claim={claim}
            evidenceList={claimEvidence}
          />
        </TabsContent>

        <TabsContent value="export">
          <ClaimEvidenceExport 
            claim={claim}
            evidenceList={claimEvidence}
            allClaims={allClaims}
            allEvidence={evidenceList}
          />
        </TabsContent>
      </Tabs>

      {showAddEvidence && (
        <AddEvidenceModal
          onClose={() => setShowAddEvidence(false)}
          onAdd={handleAddEvidence}
        />
      )}

      {showLinkEvidence && (
        <LinkEvidenceModal
          claim={claim}
          availableEvidence={evidenceList.filter(e => !e.claimIds.includes(claim.id))}
          onClose={() => setShowLinkEvidence(false)}
          onLink={onLinkEvidence}
        />
      )}
    </div>
  );
};
