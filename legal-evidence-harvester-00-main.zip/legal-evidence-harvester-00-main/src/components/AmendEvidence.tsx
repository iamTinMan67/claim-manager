
import { useState } from "react";
import { Evidence } from "@/types/evidence";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { ChevronUp, ChevronDown, Save } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Props {
  evidenceList: Evidence[];
  onUpdateEvidence: (evidenceId: string, updates: Partial<Evidence>) => void;
  onReorderEvidence: (evidenceList: Evidence[]) => void;
}

export const AmendEvidence = ({ evidenceList, onUpdateEvidence, onReorderEvidence }: Props) => {
  const [localEvidence, setLocalEvidence] = useState<Evidence[]>([...evidenceList]);
  const [hasChanges, setHasChanges] = useState(false);

  const handleFieldChange = (index: number, field: 'exhibit_id' | 'number_of_pages', value: string | number) => {
    const updated = [...localEvidence];
    if (field === 'exhibit_id') {
      updated[index] = { ...updated[index], exhibit_id: value as string };
    } else if (field === 'number_of_pages') {
      updated[index] = { ...updated[index], number_of_pages: value === '' ? null : Number(value) };
    }
    setLocalEvidence(updated);
    setHasChanges(true);
  };

  const moveItem = (index: number, direction: 'up' | 'down') => {
    if ((direction === 'up' && index === 0) || (direction === 'down' && index === localEvidence.length - 1)) {
      return;
    }

    const updated = [...localEvidence];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    // Swap items
    [updated[index], updated[targetIndex]] = [updated[targetIndex], updated[index]];
    
    setLocalEvidence(updated);
    setHasChanges(true);
  };

  const handleSaveChanges = () => {
    // Update individual evidence items
    localEvidence.forEach((evidence, index) => {
      const original = evidenceList.find(e => e.id === evidence.id);
      if (original && (
        original.exhibit_id !== evidence.exhibit_id || 
        original.number_of_pages !== evidence.number_of_pages
      )) {
        onUpdateEvidence(evidence.id, {
          exhibit_id: evidence.exhibit_id,
          number_of_pages: evidence.number_of_pages
        });
      }
    });

    // Update order if changed
    const orderChanged = localEvidence.some((evidence, index) => 
      evidenceList[index]?.id !== evidence.id
    );
    
    if (orderChanged) {
      onReorderEvidence(localEvidence);
    }

    setHasChanges(false);
    toast({
      title: "Changes Saved",
      description: "Evidence items have been updated successfully.",
    });
  };

  const handleReset = () => {
    setLocalEvidence([...evidenceList]);
    setHasChanges(false);
  };

  if (evidenceList.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>No evidence items to amend.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Amend Evidence</h3>
        <div className="space-x-2">
          {hasChanges && (
            <Button variant="outline" onClick={handleReset}>
              Reset
            </Button>
          )}
          <Button 
            onClick={handleSaveChanges}
            disabled={!hasChanges}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Changes
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        {localEvidence.map((evidence, index) => (
          <div key={evidence.id} className="bg-white border rounded-lg p-4">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
              {/* Order Controls */}
              <div className="md:col-span-1 flex flex-col space-y-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => moveItem(index, 'up')}
                  disabled={index === 0}
                  className="p-1"
                >
                  <ChevronUp className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => moveItem(index, 'down')}
                  disabled={index === localEvidence.length - 1}
                  className="p-1"
                >
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </div>

              {/* Description */}
              <div className="md:col-span-5">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <p className="text-sm text-gray-900 p-2 bg-gray-50 rounded border">
                  {evidence.description}
                </p>
              </div>

              {/* Exhibit ID */}
              <div className="md:col-span-3">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Exhibit Number
                </label>
                <Input
                  value={evidence.exhibit_id || ''}
                  onChange={(e) => handleFieldChange(index, 'exhibit_id', e.target.value)}
                  placeholder="Ex: A-001"
                  className="w-full"
                />
              </div>

              {/* Number of Pages */}
              <div className="md:col-span-3">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Number of Pages
                </label>
                <Input
                  type="number"
                  min="1"
                  value={evidence.number_of_pages || ''}
                  onChange={(e) => handleFieldChange(index, 'number_of_pages', e.target.value)}
                  placeholder="Pages"
                  className="w-full"
                />
              </div>
            </div>

            {/* File info */}
            {evidence.file_name && (
              <div className="mt-3 pt-3 border-t">
                <p className="text-sm text-gray-600">
                  <strong>File:</strong> {evidence.file_name}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>

      {hasChanges && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-sm text-yellow-800">
            You have unsaved changes. Click "Save Changes" to apply them.
          </p>
        </div>
      )}
    </div>
  );
};
