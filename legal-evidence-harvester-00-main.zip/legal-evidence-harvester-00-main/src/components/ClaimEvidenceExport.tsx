
import { useState } from "react";
import { Claim } from "@/hooks/useClaims";
import { Evidence } from "@/hooks/useEvidence";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Download, FileText, BarChart3 } from "lucide-react";
import { generateClaimEvidencePDF, generateEvidenceSummaryPDF } from "@/utils/pdfExport";
import { toast } from "@/hooks/use-toast";

interface Props {
  claim: Claim;
  evidenceList: Evidence[];
  allClaims: Claim[];
  allEvidence: Evidence[];
}

export const ClaimEvidenceExport = ({ claim, evidenceList, allClaims, allEvidence }: Props) => {
  const [generating, setGenerating] = useState(false);

  const handleExportClaimEvidence = async () => {
    setGenerating(true);
    try {
      const pdf = generateClaimEvidencePDF(claim, evidenceList);
      const fileName = `${claim.case_number}_Evidence_Report.pdf`;
      pdf.save(fileName);
      
      toast({
        title: "Export Successful",
        description: `Evidence report saved as ${fileName}`,
      });
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast({
        title: "Export Failed",
        description: "Failed to generate PDF report. Please try again.",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  const handleExportSummary = async () => {
    setGenerating(true);
    try {
      const pdf = generateEvidenceSummaryPDF(allClaims, allEvidence);
      const fileName = `Evidence_Summary_Report.pdf`;
      pdf.save(fileName);
      
      toast({
        title: "Export Successful",
        description: `Summary report saved as ${fileName}`,
      });
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast({
        title: "Export Failed",
        description: "Failed to generate PDF report. Please try again.",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  const exportEvidenceCSV = () => {
    const headers = ['Exhibit ID', 'Description', 'File Name', 'Created Date', 'Claims Count'];
    const csvContent = [
      headers.join(','),
      ...evidenceList.map(evidence => [
        `"${evidence.exhibit_id || ''}"`,
        `"${evidence.description.replace(/"/g, '""')}"`,
        `"${evidence.file_name || ''}"`,
        `"${new Date(evidence.created_at).toLocaleDateString()}"`,
        evidence.claimIds.length
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${claim.case_number}_Evidence_Data.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);

    toast({
      title: "CSV Export Successful",
      description: `Evidence data saved as ${claim.case_number}_Evidence_Data.csv`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="w-5 h-5" />
              <span>Claim Evidence Report</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              Generate a comprehensive PDF report for this claim including all evidence items, descriptions, and file attachments.
            </p>
            <div className="space-y-2">
              <Button 
                onClick={handleExportClaimEvidence}
                disabled={generating}
                className="w-full"
              >
                <Download className="w-4 h-4 mr-2" />
                {generating ? "Generating PDF..." : "Download PDF Report"}
              </Button>
              <Button 
                onClick={exportEvidenceCSV}
                variant="outline"
                className="w-full"
              >
                <Download className="w-4 h-4 mr-2" />
                Download CSV Data
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="w-5 h-5" />
              <span>Evidence Summary</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              Generate a summary report of all evidence across all claims in your system.
            </p>
            <Button 
              onClick={handleExportSummary}
              disabled={generating}
              className="w-full"
              variant="outline"
            >
              <Download className="w-4 h-4 mr-2" />
              {generating ? "Generating PDF..." : "Download Summary Report"}
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Export Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600">{evidenceList.length}</div>
              <div className="text-sm text-gray-600">Evidence Items</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">
                {evidenceList.filter(e => e.file_name).length}
              </div>
              <div className="text-sm text-gray-600">With Files</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">{allClaims.length}</div>
              <div className="text-sm text-gray-600">Total Claims</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-orange-600">{allEvidence.length}</div>
              <div className="text-sm text-gray-600">Total Evidence</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
