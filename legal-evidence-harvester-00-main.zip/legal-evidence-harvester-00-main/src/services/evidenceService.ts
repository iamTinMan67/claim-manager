
import { supabase } from '@/integrations/supabase/client';
import { Evidence } from '@/types/evidence';
import { retryWithReauth } from '@/utils/authUtils';

export class EvidenceService {
  static async fetchEvidence(): Promise<Evidence[]> {
    const operation = async () => {
      const { data: evidenceData, error: evidenceError } = await supabase
        .from('evidence')
        .select(`
          *,
          evidence_claims (
            claim_id
          )
        `)
        .order('created_at', { ascending: false });

      if (evidenceError) throw evidenceError;

      const mappedEvidence: Evidence[] = evidenceData?.map(item => ({
        id: item.id,
        description: item.description,
        file_name: item.file_name,
        file_url: item.file_url,
        exhibit_id: item.exhibit_id,
        number_of_pages: item.number_of_pages,
        created_at: item.created_at,
        updated_at: item.updated_at,
        claimIds: item.evidence_claims?.map((ec: any) => ec.claim_id) || []
      })) || [];

      return mappedEvidence;
    };

    return await retryWithReauth(operation);
  }

  static async createEvidence(
    evidenceData: Omit<Evidence, 'id' | 'created_at' | 'updated_at' | 'claimIds'>,
    userId: string
  ): Promise<any> {
    const operation = async () => {
      const { data, error } = await supabase
        .from('evidence')
        .insert([{ 
          description: evidenceData.description,
          file_name: evidenceData.file_name,
          file_url: evidenceData.file_url,
          exhibit_id: evidenceData.exhibit_id,
          number_of_pages: evidenceData.number_of_pages,
          user_id: userId 
        }])
        .select()
        .single();

      if (error) {
        console.error('Evidence insert error:', error);
        throw error;
      }

      console.log('Evidence created successfully:', data);
      return data;
    };

    return await retryWithReauth(operation);
  }

  static async linkEvidenceToClaims(evidenceId: string, claimIds: string[]): Promise<void> {
    if (claimIds.length === 0) return;

    const operation = async () => {
      const linkData = claimIds.map(claimId => ({
        evidence_id: evidenceId,
        claim_id: claimId
      }));

      console.log('Linking evidence to claims:', linkData);

      const { error: linkError } = await supabase
        .from('evidence_claims')
        .insert(linkData);

      if (linkError) {
        console.error('Evidence linking error:', linkError);
        throw linkError;
      }

      console.log('Evidence linked to claims successfully');
    };

    await retryWithReauth(operation);
  }

  static async deleteEvidence(id: string): Promise<void> {
    const operation = async () => {
      const { error } = await supabase
        .from('evidence')
        .delete()
        .eq('id', id);

      if (error) throw error;
    };

    await retryWithReauth(operation);
  }

  static async linkEvidenceToClaim(evidenceId: string, claimId: string): Promise<void> {
    const operation = async () => {
      const { error } = await supabase
        .from('evidence_claims')
        .insert([{ evidence_id: evidenceId, claim_id: claimId }]);

      if (error) throw error;
    };

    await retryWithReauth(operation);
  }

  static async unlinkEvidenceFromClaim(evidenceId: string, claimId: string): Promise<void> {
    const operation = async () => {
      const { error } = await supabase
        .from('evidence_claims')
        .delete()
        .eq('evidence_id', evidenceId)
        .eq('claim_id', claimId);

      if (error) throw error;
    };

    await retryWithReauth(operation);
  }
}
